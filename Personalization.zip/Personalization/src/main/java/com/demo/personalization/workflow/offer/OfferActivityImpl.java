package com.demo.personalization.workflow.offer;

import io.temporal.spring.boot.ActivityImpl;
import org.springframework.stereotype.Component;

import java.util.Random;

@Component
@ActivityImpl(taskQueues = "offer-creation-tasks")
public class OfferActivityImpl implements OfferActivities {
    final Random random = new Random();

    @Override
    public boolean initiateOfferCreation() {
        System.out.println("Initializing offer creation");
        return random.nextBoolean();
    }

    @Override
    public boolean loadOfferAttributes() {
        System.out.println("Loading offer attributes");
        return random.nextBoolean();
    }

    @Override
    public boolean createOffers() {
        System.out.println("Initializing offer creation");
        return random.nextBoolean();
    }
}
