package com.demo.personalization.workflow.offer;

import io.temporal.activity.ActivityOptions;
import io.temporal.common.RetryOptions;
import io.temporal.spring.boot.WorkflowImpl;
import io.temporal.workflow.Workflow;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.function.Supplier;

@Service
@WorkflowImpl(taskQueues = "offer-creation-tasks")
public class OfferCreationWorkFlowImpl implements OfferCreationWorkFlow {

    private volatile String status = "PENDING";

    private volatile String rejectionReason;

    private final Supplier<OfferActivities> activities;

    public OfferCreationWorkFlowImpl() {
        this.activities
                = () -> Workflow.newActivityStub(
                OfferActivities.class,
                ActivityOptions.newBuilder()
                        .setStartToCloseTimeout(Duration.ofSeconds(10))
                        .setRetryOptions(RetryOptions.newBuilder()
                                .setMaximumAttempts(3)
                                .setInitialInterval(Duration.ofSeconds(1))
                                .build())
                        .build()
        );
    }


    @Override
    public void createOffer() {
        var activity = activities.get();

        var result = activity.initiateOfferCreation();
        evaluateResult(result, "initiate");
        Workflow.await(() -> !"PENDING".equals(status));

        result = activity.loadOfferAttributes();
        evaluateResult(result, "load");
        Workflow.await(() -> !"PENDING".equals(status));

        result = activity.createOffers();
        evaluateResult(result, "create");
        Workflow.await(() -> !"PENDING".equals(status));
    }

    private void evaluateResult(boolean result, String activity){
        if(!result){
            status = "REJECTED";
            rejectionReason = activity;
        }
    }

    @Override
    public void approve() {
        status = "APPROVED";
    }

    @Override
    public void reject(String reason) {
        status = "REJECTED";
        rejectionReason = reason;
    }

    @Override
    public String getStatus() {
        return status;
    }

    @Override
    public String getRejectReason() {
        return rejectionReason;
    }
}
