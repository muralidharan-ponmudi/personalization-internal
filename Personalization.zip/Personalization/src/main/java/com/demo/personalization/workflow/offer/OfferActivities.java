package com.demo.personalization.workflow.offer;

import io.temporal.activity.ActivityMethod;

public interface OfferActivities {

    @ActivityMethod
    boolean initiateOfferCreation();

    @ActivityMethod
    boolean loadOfferAttributes();

    @ActivityMethod
    boolean createOffers();
}
