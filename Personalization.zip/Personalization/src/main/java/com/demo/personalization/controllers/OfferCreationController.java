package com.demo.personalization.controllers;

import com.demo.personalization.workflow.offer.OfferCreationWorkFlow;
import io.temporal.client.WorkflowClient;
import io.temporal.client.WorkflowOptions;
import io.temporal.serviceclient.WorkflowServiceStubs;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/offers")
public class OfferCreationController {

    private final WorkflowClient workflowClient = WorkflowClient.newInstance(
            WorkflowServiceStubs.newLocalServiceStubs());


    @PostMapping("/start")
    public String start(@RequestParam String workFlowId) {

        OfferCreationWorkFlow workflow =
                workflowClient.newWorkflowStub(
                        OfferCreationWorkFlow.class,
                        WorkflowOptions.newBuilder()
                                .setWorkflowId(workFlowId)
                                .setTaskQueue("offer-creation-tasks")
                                .build()
                );

        WorkflowClient.start(workflow::createOffer);
        return "Workflow started for document " + workFlowId;
    }
}