package com.demo.personalization.workflow.offer;

import io.temporal.workflow.QueryMethod;
import io.temporal.workflow.SignalMethod;
import io.temporal.workflow.WorkflowInterface;
import io.temporal.workflow.WorkflowMethod;

@WorkflowInterface
public interface OfferCreationWorkFlow {

    @WorkflowMethod
    void createOffer();

    @SignalMethod
    void approve();

    @SignalMethod
    void reject(String reason);

    @QueryMethod
    String getStatus();

    @QueryMethod
    String getRejectReason();
}
