package com.demo.personalization;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.vaadin.flow.component.dependency.StyleSheet;
import com.vaadin.flow.component.page.AppShellConfigurator;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.demo.personalization"})
@StyleSheet("styles.css")
public class PersonalizationApplication implements AppShellConfigurator {

    public static void main(String[] args) {
        SpringApplication.run(PersonalizationApplication.class, args);
    }
}
