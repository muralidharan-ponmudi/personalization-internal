package com.demo.personalization;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonalizationApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonalizationApplication.class, args);
	}

}
